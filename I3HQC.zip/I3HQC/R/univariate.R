
#' @title Create binned histograms for your data.
#' @description Channel-wise binning of events by protein expression,
#' useful for visualization and computing JS divergence.
#' @param qc_data An object of type qc_data, obtained from read_data.
#' @param name_col Name of column in manifest where unique identifiers
#' of files can be found.
#' @param range The range of protein expression values to consider: uniform
#' across all channels, default value assumes acrsinh transformed data
#' with cofactor 5.
#' @param nbins Integer, controls the number of bins for coarser or finer
#' density estimates.
#' @export
binned_histograms <- function(qc_data, name_col="file",
                              range=c(-1,8), nbins=200) {

  sample_names <- qc_data$manifest %>% pull(name_col)

  hist_list <- Map(function(mat, idx, name) {
    hist_single_mat(mat[idx,qc_data$cols_analysis], name, range, nbins)
  }, qc_data$data_list, qc_data$index_list, sample_names)

  hist <- do.call(what=rbind, hist_list)

  hist <- inner_join(hist, qc_data$manifest, by=name_col)

  return(hist)
}


hist_single_mat <- function(mat, name, range=c(-1,8), nbins=200) {
  channels <- colnames(mat)
  step <- (range[2]-range[1])/nbins
  breaks <- range[1] + seq(0,nbins) * step
  labels <- breaks[-1]-step/2

  lapply(channels, function(channel) {
    bins <- cut(mat[,channel], breaks=breaks, labels=seq(nbins))
    tab <- as.integer(table(bins[which(!is.na(bins))]))
    tabular <- tibble(protein_expression = labels,
                      frac_events = tab/sum(tab),
                      channel = channel,
                      file = name)
  }) %>% do.call(what=rbind)
}


#' @title Jensen-Shannon divergence between arbitrary discrete distributions
#' @param mat A matrix whose columns are discrete distributions to be compared.
#' @returns A data frame with a row for every pair of distributions (columns)
#' in the input matrix.
#' @export
get_js_matrix <- function(mat) {
  js_mat <- js_matrix(mat)

  if (is.null(colnames(mat))) {
    names <- seq(ncol(mat))
  } else {
    names <- colnames(mat)
  }
  colnames(js_mat) <- names

  js_df <- js_mat %>%
    as_tibble() %>%
    mutate(dist1 = names) %>%
    pivot_longer(-dist1, names_to="dist2", values_to="js_div")

  return(js_df)
}


#' @title Compute Jensen-Shannon divergence between all 1d histograms
#' @param hist Data frame of histogram information, obtained from
#' binned_histograms.
#' @returns A data frame with a row for every pair of files and every channel.
#' @export
get_js_hist <- function(hist) {
  channels <- unique(hist$channel)
  files <- unique(hist$file)

  js_all <- lapply(channels, function(ch) {
    hist_ch <- hist %>%
      filter(channel==ch) %>%
      select(file, protein_expression, frac_events) %>%
      pivot_wider(names_from = "file", values_from = "frac_events") %>%
      select(-protein_expression) %>%
      as.matrix()

    js_mat <- js_matrix(hist_ch)
    colnames(js_mat) <- files

    js_df <- js_mat %>%
      as_tibble() %>%
      mutate(file1 = files) %>%
      pivot_longer(-file1, names_to="file2", values_to="js_div") %>%
      mutate(channel=ch)
  }) %>% do.call(what=rbind)

  return(js_all)
}


#' @title Compute file score by averaging JS divergence over all channels.
#' @param js A data frame with JS divergence for every pair of files
#' and every channel, obtained from get_js_hist
#' @param cutoff JS score above which a file fails QC; if not null,
#' overrides n_sd_cutoff.
#' @param n_sd_cutoff Number of standard deviations above mean JS score
#' considered a cutoff for QC pass/fail.
#' @param precision Number of digits of precision to keep.
#' @returns A data frame with a row for every file, giving a JS score
#' averaged over all channels and all other files to be compared.
#' @export
average_js_score <- function(js, cutoff=NULL, n_sd_cutoff=2, precision=3) {
  js_with_score <- js %>%
    group_by(file1) %>%
    summarise(js_score = round(mean(js_div),precision))

  m <- mean(js_with_score$js_score)
  s <- sd(js_with_score$js_score)
  if (is.null(cutoff))
    cutoff <- m + n_sd_cutoff * s

  message(paste0("Mean JS score: ", round(m,precision),
                 "; sd: ", round(s,precision), "; cutoff:",
                 round(cutoff,precision), "."))

  js_with_score <- js_with_score %>%
    mutate(qc_pass = js_score < cutoff) %>%
    mutate(file = file1, .keep="unused") %>%
    relocate(file)

  n_pass <- length(which(js_with_score$qc_pass))
  n_fail <- length(which(!js_with_score$qc_pass))

  message(paste0(n_pass, " files passed QC and ", n_fail, " failed."))

  return(js_with_score)
}


#' @title Plot heatmap of JS divergence for all files.
#' @export
plot_js_all <- function(js) {
  ggplot(js, aes(x=file1, y=file2, fill=js_div)) +
    geom_tile() +
    scale_fill_gradient(low="white", high="red", limits=c(0,1), name="JS") +
    facet_wrap(~channel) +
    ggtitle("Jensen-Shannon divergence between all samples") +
    theme_bw() +
    theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1),
          plot.title = element_text(hjust = 0.5),
          strip.background = element_blank())
}


#' @title Plot heatmap of JS divergence for a single channel.
#' @export
plot_js_channel <- function(js, ch) {
  lev <- unique(js$file1)
  js_channel <- js %>%
    filter(channel==ch) %>%
    mutate(file1 = factor(file1, levels=lev),
           file2 = factor(file2, levels=lev))
  ggplot(js_channel, aes(x=file1, y=file2, fill=js_div)) +
    geom_tile() +
    scale_fill_gradient(low="white", high="red", limits=c(0,1), name="JS") +
    # ggtitle("JS divergence between CD4 distributions in pairs of files") +
    xlab(NULL) +
    ylab(NULL) +
    theme_bw(base_size=16) +
    theme(axis.text.x = element_text(angle=90, vjust=0.5, hjust=1))
}


#' @title Plot heatmap of JS divergence for control files.
#' @export
plot_js_control <- function(js, manifest) {
  ctrl_files <- manifest %>% filter(control) %>% pull(file)
  js_ctrl <- js %>% filter(file1 %in% ctrl_files, file2 %in% ctrl_files)

  ggplot(js_ctrl, aes(x=file1, y=file2, fill=js_div)) +
    geom_tile() +
    scale_fill_gradient(low="white", high="red", limits=c(0,1), name="JS") +
    facet_wrap(~channel) +
    ggtitle("Jensen-Shannon divergence between control samples") +
    theme_bw() +
    theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1),
          plot.title = element_text(hjust = 0.5),
          strip.background = element_blank())
}


plot_zoomed_in_zero <- function(df, color_col, f_name, title) {
  f <- match.fun(f_name)
  val <- df$protein_expression[which.min(abs(df$protein_expression))]

  p <- df %>%
    f(color_col, title) %>%
    ggplot_build()

  plim <- df %>%
    filter(!protein_expression == val) %>%
    f(color_col, title) %>%
    ggplot_build()

  p$layout$panel_params <- plim$layout$panel_params
  grid.draw(ggplot_gtable(p))
}


#' @title Plot histograms for all files.
#' @export
plot_hist_all <- function(hist, ch, color_col) {
  df <- hist %>% filter(channel == ch)
  val <- df$protein_expression[which.min(abs(df$protein_expression))]
  up <- df %>% filter(!protein_expression == val) %>%
    pull(frac_events) %>% max()

  ggplot(df, aes(x=protein_expression, y=frac_events, group=file)) +
    geom_line(aes(color=.data[[color_col]])) +
    ggtitle(paste0("Distribution of ", ch, " in all files")) +
    theme_bw(base_size=14) +
    coord_cartesian(ylim=c(0,up)) +
    theme(plot.title = element_text(hjust = 0.5),
          strip.background = element_blank())
}


#' @title Plot histograms for control files.
#' @export
plot_hist_control <- function(hist, ch, color_col) {
  df <- hist %>% filter(control & channel == ch)
  val <- df$protein_expression[which.min(abs(df$protein_expression))]
  up <- df %>% filter(!protein_expression == val) %>%
    pull(frac_events) %>% max()

  ggplot(df, aes(x=protein_expression, y=frac_events, group=file)) +
    geom_line(aes(color=.data[[color_col]])) +
    ggtitle(paste0("Distribution of ", ch, " in technical controls")) +
    theme_bw(base_size=14) +
    coord_cartesian(ylim=c(0,up)) +
    theme(plot.title = element_text(hjust = 0.5),
          strip.background = element_blank())
}


#' @title Facet plot of histograms for all files.
#' @export
plot_hist_facets_all <- function(hist, color_col) {
  plot_zoomed_in_zero(hist, color_col, "make_hist_facets",
                      title="Univariate distributions in all files")
}


#' @title Facet plot of histograms for control files.
#' @export
plot_hist_facets_control <- function(hist, color_col) {
  plot_zoomed_in_zero(hist %>% filter(control), color_col, "make_hist_facets",
                      title="Univariate distributions in technical controls")
}

make_hist_facets <- function(df, color_col, title) {
  ggplot(df, aes(x=protein_expression, y=frac_events, group=file)) +
    geom_line(aes(color=.data[[color_col]])) +
    facet_wrap(~channel, scales="free_y") +
    ggtitle(title) +
    theme_minimal(base_size=14) +
    theme(plot.title = element_text(hjust = 0.5),
          strip.background = element_blank())
}





