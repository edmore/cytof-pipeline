as_cumulative <- function(df) {
  hier <- c("Beads", "Cleanup1", "Cleanup2",
            "Cleanup3", "Cleanup4", "Cleanup5",
            "Cleanup6", "Ir", "CD45")

  for (i in seq(length(hier), 2, -1)) {
    df[[hier[i]]] <- df[["Events Count"]] - apply(df[hier[seq(1,i-1)]], 1, sum)
  }

  return(df)
}


#' @title Table summarizing bead and cleanup gates
#' @description Use pre-gating cell labels to summarize bead and cleanup gates
#' per file, and flag outliers.
#' @param qc_data An object of type qc_data, obtained from read_data.
#' @returns A mmtable2 object.
#' @export
get_cleanup_table <- function(qc_data) {

  tab_list <- lapply(qc_data$data_list, function(mat) {
    table(qc_data$omiq_array[mat[,"OmiqFilter"]])
  })

  df_cleanup <- tibble(count = do.call(c, tab_list),
                       feature = do.call(c, lapply(tab_list, names)),
                       file = rep(manifest$file, times=sapply(tab_list, length))) %>%
    pivot_wider(names_from = "feature", values_from = "count", values_fill=0) %>%
    mutate(`Events Count` = sapply(qc_data$data_list, nrow)) %>%
    select(file, `Events Count`, Beads, Cleanup1, Cleanup2,
           Cleanup3, Cleanup4, Cleanup5, Cleanup6, Ir, CD45) %>%
    as_cumulative() %>%
    mutate(`CD45 Count` = CD45,
           `Excluded Count` = `Events Count` - CD45,
           `CD45 %Total` = 100*CD45/`Events Count`,
           `Beads %Total` = 100*Beads/`Events Count`,
           `Clean1 %Parent` = 100*Cleanup1/`Events Count`,
           `Clean2 %Parent` = 100*Cleanup2/Cleanup1,
           `Clean3 %Parent` = 100*Cleanup3/Cleanup2,
           `Clean4 %Parent` = 100*Cleanup4/Cleanup3,
           `Clean5 %Parent` = 100*Cleanup5/Cleanup4,
           `Clean6 %Parent` = 100*Cleanup6/Cleanup5,
           `Ir %Parent` = 100*Ir/Cleanup6,
           `CD45 %Parent` = 100*CD45/Ir,
           `Beads Count` = Beads) %>%
    select(-Cleanup1, -Cleanup2, -Cleanup3,
           -Cleanup4, -Cleanup5, -Cleanup6,
           -Ir, -CD45, -Beads, -`Excluded Count`, -`Beads Count`, -`CD45 Count`) %>%
    pivot_longer(-file, names_to="Feature", values_to="Value") %>%
    mutate(Feature_name = Feature %>% str_split(" ") %>%
             sapply(function(x) paste(x[-length(x)], collapse=" ")),
           Feature_type = Feature %>% str_split(" ") %>%
             sapply(function(x) x[length(x)])) %>%
    mutate(Value = round(Value,1)) %>%
    mutate(Feature_type=factor(Feature_type, levels=c("Count", "%Total", "%Parent")),
           Feature_name=factor(Feature_name, levels=c("Clean1", "Clean2", "Clean3",
                                                      "Clean4", "Clean5", "Clean6",
                                                      "Ir", "Events", "CD45",
                                                      "Beads", "Excluded")))


  m <- mmtable(df_cleanup, cells=Value) +
    header_left(file) +
    header_top(Feature_name) +
    header_top_left(Feature_type) +
    table_title("Beads and Cleanup Report") +
    cells_format(Feature=="Beads %Total" & Value>10 |
                   Feature=="CD45 %Total" & Value < 50,
                 cell_text(color="red"))
  m$`_data`[[1]][2] <- "File"

  return(m)
}


#' @title Channel stability over time
#' @description Compute JS divergence between time slices and flag
#' non-stationary acquisition.
#' @param qc_data An object of type qc_data, obtained from read_data.
#' @returns A data frame containing JS divergence for each file, channel
#' and time slice.
#' @export
get_js_time <- function(qc_data) {
  Map(function(mat, f) {
    channels <- setdiff(colnames(mat), c("Time", "OmiqFilter"))

    js_time <- lapply(channels, js_time_single_mat, mat=mat) %>%
      do.call(what=rbind) %>%
      mutate(file = f)

    p <- ggplot(js_time, aes(x=dist1, y=channel, fill=js_div)) +
      geom_tile() +
      scale_fill_gradient(low="white", high="red", limits=c(0,1)) +
      xlab("Time slice") +
      ggtitle(paste0("JS divergence between time slices for file ", f)) +
      theme_bw(base_size=14)
    ggsave(p, filename=paste0(dir_out, "/figures/time/js/", f, ".png"),
           width=9, height=8)

    # channels <- c("140Ce_Bead", "Residual", "DNA1", "CD66b")
    # tib <- as_tibble(mat[,c("Time",channels)])
    # for (ch in channels) {
    #   p <- ggplot(tib, aes(x=Time, y=.data[[ch]])) +
    #     geom_bin_2d(bins=100) +
    #     scale_fill_viridis_c() +
    #     ggtitle(paste0("Bead distribution over time for file ", f)) +
    #     theme_bw(base_size=16)
    #   ggsave(p, filename=paste0(dir_out, "/figures/time/", ch, "/", f, ".png"),
    #          width=9, height=8)
    # }

    return(js_time)
  }, qc_data$data_list, qc_data$manifest$file) %>%
    do.call(what=rbind)
  # names(js_time_list) <- qc_data$manifest$file
}


#' @title Plot non-stationary acquisition.
#' @description Select file/channel pairs with non-stationary acquisition
#' and save a density plot.
#' @param qc_data An object of type qc_data, obtained from read_data.
#' @param df A data frame containing js divergence between tiem slices.
#' @param dir_out Output directory for saving plots.
#' @param cutoff Numeric, JS values higher than cutoff are considered outliers.s
#' @export
plot_time_outliers <- function(qc_data, df, dir_out, cutoff=0.1) {
  df_cut <- df %>% filter(max_js_div > cutoff)

  for (i in seq(nrow(df_cut))) {
    f <- df_cut$file[i]
    ch <- df_cut$channel[i]

    tib <- as_tibble(qc_data$data_list[[f]][,c("Time", ch)])
    p <- ggplot(tib, aes(x=Time, y=.data[[ch]])) +
      geom_bin_2d(bins=100) +
      scale_fill_viridis_c() +
      ggtitle(paste0("Time distribution of ", ch, " in file ", f)) +
      theme_bw(base_size=16)
    ggsave(p, filename=paste0(dir_out, "/figures/time/outliers/", f, "_", ch, ".png"),
           width=9, height=8)
  }
}


js_time_single_mat <- function(ch, mat) {
  nbin <- 30
  m1 <- max(mat[,"Time"])
  m2 <- max(mat[,ch])
  bins <- bin2(mat[,c("Time", ch)], nbin=c(nbin, nbin),
               ab=c(0, 0, m1, m2))

  bins$nc %>% apply(1, function(row) row/sum(row)) %>%
    get_js_matrix() %>%
    filter(!is.na(js_div)) %>%
    group_by(dist1) %>%
    summarise(js_div = mean(js_div)) %>%
    mutate(channel=ch)
}




