#' @title Manifest of files in given directory
#' @description Make a manifest on the fly, to keep track of files, file
#' paths and some optional metadata parsed from file names.
#' @param dir Directory where files are located.
#' @param file_pattern A glob to be pattern matched for filtering files
#' in directory.
#' @param control_pattern Optionally, create a TRUE/FALSE column labeling
#' some files as technical controls, based on a pattern in file names.
#' @returns A data frame with columns for file names, file paths and
#' optionally technical control status.
#' @export
make_manifest <- function(dir, file_pattern="fcs", control_pattern=NULL) {
  files <- list.files(dir, pattern = file_pattern)
  paths <- paste0(dir, "/", files)
  date <- sapply(paths, read.FCSheader, keyword="$DATE") %>%
    unlist() %>% unname() %>% dmy() %>% as.factor()

  manifest <- tibble(file_id = seq_along(files),
                     file = files %>%
                       str_remove(".fcs") %>%
                       str_remove("_Processed") %>%
                       str_remove("_Normalized"),
                     date = date,
                     path = paths)

  if (!is.null(control_pattern)) {
    manifest <- manifest %>%
      mutate(control = grepl(control_pattern, files))
  }

  return(manifest)
}


#' @title Read and parse FCS format
#' @description Read, data transformation, descriptive column names and
#' optional downsampling.
#' @param manifest A data frame with fcs file metadata, including a column
#' named "path" to be used for reading the files.
#' @param omiq_key_file Path to the location of a csv file describing numeric
#' encoding of cell types. (Typically named _FilterValuesToNames.csv)
#' @param transform Logical, whether to apply hyperbolic arcsin transformation
#' to data.
#' @param trans_pattern A regular expression to be pattern matched with grep,
#' to find metal channels which should be arcsinh transformed. Ignored if
#' transform=FALSE.
#' @param simplify_colnames Logical, whether to strip metal isotope from
#' column names and only keep protein name.
#' @returns A matrix of protein expression data, with cells along rows
#' and proteins along columns.
#' @export
read_data <- function(manifest, omiq_key_file=NULL,
                      transform=TRUE, trans_pattern="Di",
                      simplify_colnames=TRUE) {
  if (transform) {
    message(paste0("Performing asinh transform of all metal channels. ",
                   "Assuming that metal channels are the ones containing ",
                   "the pattern ", trans_pattern, ", for example Ce140Di. ",
                   "Use arguments transform ",
                   "and trans_pattern if you want to change this behavior."))
  } else {
    message("Not performing any data transformation.")
  }

  data_list <- lapply(manifest$path, read_single_mat,
                      transform=transform, trans_pattern=trans_pattern,
                      simplify_colnames=simplify_colnames)
  names(data_list) <- manifest$file

  df <- get_fcs_params_df(manifest$path[1])
  cols <- df$desc
  rm_patt <- "Time|length|Bead|DNA|Live|Center|Offset|Width|Residual|Omiq"
  keep_ind <- which(!grepl(rm_patt, cols) & grepl("_", cols))
  rm_gates <- "Root|Beads|Cleanup|Ir"

  if (is.null(omiq_key_file)) {
    message("No OMIQ key file provided. All events will be used for analysis.")
    omiq_array <- NULL
  } else {
    omiq_keys <- read_csv(omiq_key_file,
                          col_names=c("Key", "Name"),
                          skip=1, show_col_types = FALSE)
    omiq_array <- setNames(omiq_keys$Name, as.character(omiq_keys$Key))
  }

  cols_base <- colnames(data_list[[1]])
  qc_data <- list(data_list=data_list,
                  cols_analysis=cols_base[keep_ind],
                  cols_trans=cols_base[grep(trans_pattern, cols_base)],
                  rm_gates=rm_gates,
                  omiq_array=omiq_array,
                  manifest=manifest)
  class(qc_data) <- "qc_data"

  qc_data <- aggregate_data(qc_data)

  return(qc_data)
}

aggregate_data <- function(qc_data) {

  qc_data$index_list <- lapply(qc_data$data_list, function(mat) {
    if (is.null(qc_data$omiq_array) |
        length(grep("OmiqFilter", colnames(mat)))==0)
      return(seq(nrow(mat)))

    idx <- which(!grepl(qc_data$rm_gates,
                 qc_data$omiq_array[mat[,"OmiqFilter"]]))
    return(idx)
  })

  n_each <- sapply(qc_data$index_list, length)

  qc_data$data <- Map(function(mat, idx) {
    mat[idx,qc_data$cols_analysis]
  }, qc_data$data_list, qc_data$index_list) %>%
    do.call(what=rbind)

  qc_data$file_array <- as.factor(rep(qc_data$manifest$file_id, times=n_each))

  return(qc_data)
}


get_fcs_params_df <- function(path) {
  ff <- suppressWarnings(read.FCS(path))
  return(ff@parameters@data)
}

#' @title A print method for the qc_data class.
#' @export
print.qc_data <- function(obj) {
  n <- length(obj$data_list)
  d1 <- ncol(obj$data_list[[1]])
  d2 <- length(obj$cols_analysis)
  cat("A container for cytometry QC workflow with", n, "files.",
      "There are", d1, "channels,", d2, "of which will be used for",
      "analysis:\n")
  print(obj$cols_analysis)
}


read_single_mat <- function(path, transform, trans_pattern, simplify_colnames) {
  ff <- suppressWarnings(read.FCS(path))
  data <- ff@exprs

  if (transform) {
    trans_cols <- grep(trans_pattern, colnames(data))
    data[,trans_cols] <- asinh(data[,trans_cols]/5)
  }

  colnames(data) <- as.character(ff@parameters@data$desc)

  if (simplify_colnames) {
    simplif_channels <- which(grepl("_", colnames(data)) &
                                !grepl("Bead", colnames(data)))
    simple_names <- str_split(colnames(data)[simplif_channels], "_") %>%
      sapply("[", 2)
    colnames(data)[simplif_channels] <- simple_names
  }

  return(data)
}


#' @title Write cleaned fcs files.
#' @description Exclude events from Root, Bead, Cleanup, Ir gates in the
#' IH MDIPA CyTOF gating strategy, and save the CD45+ events as a
#' separate fcs file.
#' @param qc_data An object of type qc_data, obtained from read_data.
#' @param dir Output directory for writing the files.
#' @export
write_CD45_gated_fcs <- function(qc_data, dir) {

  if(!dir.exists(paste0(dir, "/fcs_cleaned")))
    dir.create(paste0(dir, "/fcs_cleaned"))

  Map(function(mat, idx, file) {
    cols <- setdiff(colnames(mat), "OmiqFilter")
    mat_sub <- mat[idx,cols]
    mat_sub[,qc_data$cols_trans] <- 5*sinh(mat_sub[,qc_data$cols_trans])
    ff <- flowFrame(mat_sub)
    fn <- paste0(dir, "/fcs_cleaned/", file, "_Cleaned.fcs")
    write.FCS(ff, filename=fn)
  }, qc_data$data_list, qc_data$index_list, manifest$file)
}



