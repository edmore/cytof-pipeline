
#' @title Cluster SOM nodes
#' @param data Data matrix, must have same cells same order as input for
#' SOM function, but columns may be different.
#' @param som SOM result.
#' @param k Integer, number of meta-clusters to produce. Must be
#' between 1 and number of SOM nodes.
#' @return A list with two elements. "clustering" is the metacluster assignment
#' of all cells. "centroids" is a matrix of cluster centroids.
#' @export
metacluster_som <- function(data, som, k) {
  metacl <- metaClustering_consensus(som$codes, k=k)
  fsom_clustering <- as.factor(metacl[som$mapping[,1]])
  system.time(fsom_centroids <- compute_centroids(data, fsom_clustering, k=k))
  colnames(fsom_centroids) <- colnames(data)

  labels <- label_clusters(fsom_centroids, pheno_defs, thresholds = c())
  row.names(fsom_centroids) <- labels
  levels(fsom_clustering) <- labels

  metaclusters <- list(clustering=fsom_clustering,
                       centroids=fsom_centroids,
                       metacl=labels[metacl])
  return(metaclusters)
}


label_clusters <- function(centroids, defs, thresholds=c()) {
  modality <- apply(centroids, 2, get_modality)

  for (marker in names(thresholds)) {
    th <- thresholds[marker]
    modality[,marker] <- if_else(centroids[,marker] < th, "lo", "hi")
  }

  matches <- match_defs(defs, modality)
  phenos <- c(defs$Phenotype, "Other")
  labels <- phenos[matches]
  labels <- make.unique(labels)

  return(labels)
}


get_modality <- function(marker)
{
  diana <- cluster::diana(marker)
  diana_cut <- cutree(as.hclust(diana), k = 2)

  if (mean(marker[which(diana_cut == 1)]) < mean(marker[which(diana_cut == 2)])) {
    mod <- c("lo", "hi")
  }
  else {
    mod <- c("hi", "lo")
  }
  return(mod[diana_cut])
}


match_defs <- function(defs, modality) {
  ind <- integer(nrow(modality))

  for (i in seq(nrow(defs))) {
    markers <- names(defs)[which(defs[i,] %in% c("hi", "lo"))]
    match <- apply(modality[,markers,drop=FALSE], 1, function(x) {
      def <- as.character(defs[i,markers])
      chx <- as.character(x)
      all.equal(chx,def)
    })
    sel <- which(match == "TRUE")
    ind[sel] <- i
  }

  ind[which(ind==0)] <- nrow(defs)+1
  return(ind)
}


#' @title Compute EMD distance between all samples.
#' @export
get_emd <- function(samples, mapping, centroids, keep=NULL) {
  if (is.null(keep))
    keep <- seq(nrow(centroids))

  tab <- table(samples, mapping) %>%
    apply(1, function(row) {
      return(row[keep]/sum(row[keep]))
    }) %>% t()

  costm <- as.matrix(dist(centroids[keep,]))
  n <- nrow(tab)
  emd <- matrix(0, nrow=n, ncol=n)

  for (i in seq(1,n-1)) {
    print(i)
    for (j in seq(i+1,n)) {
      tr <- transport(tab[i,], tab[j,], costm=costm)
      val <- sum(costm[cbind(tr$from, tr$to)] * tr$mass)
      emd[i,j] <- emd[j,i] <- val
    }
  }

  row.names(emd) <- colnames(emd) <- row.names(tab)
  return(emd)
}


#' @title UMAP dimensional reduction taking as input a distance matrix.
#' @export
compute_umap_dist <- function(dist_mat, ids, manifest, n_neighbors=15) {
  config <- umap.defaults
  config$input <- "dist"
  config$n_neighbors <- n_neighbors
  umap_mat <- umap(dist_mat, config = config)
  df <- tibble(file_id = as.integer(ids),
               UMAP1 = umap_mat$layout[,1],
               UMAP2 = umap_mat$layout[,2]) %>%
    inner_join(manifest)
  return(df)
}


#' @title Plot umap with a discrete color scale.
#' @export
plot_umap_discrete <- function(dim_red, color_col, name_color) {
  ggplot(dim_red,
         aes(x=umap1, y=umap2, color=.data[[color_col]])) +
    geom_point(size=0.6, alpha=0.5, shape=1) +
    scale_color_discrete(name=name_color) +
    guides(color = guide_legend(override.aes = list(alpha = 1,
                                                    size = 2,
                                                    shape=19))) +
    theme_bw(base_size=16)
}


#' @title Plot umap with a continuous color scale.
#' @export
plot_umap_continuous <- function(dim_red, color_col, name_color) {
  ggplot(dim_red, aes(x=umap1, y=umap2, color=.data[[color_col]])) +
    scale_color_gradient2(low="black", mid="black", high="red",
                          name=name_color) +
    geom_point(size=0.6, alpha=0.5, shape=1) +
    theme_bw(base_size=16)
}


#' @title Compute cell type percentages from clustering.
#' @export
features_multivariate <- function(samples, clustering, manifest) {
  tab <- table(samples, clustering) %>%
    apply(1, function(row) row/sum(row)) %>% t()

  feat <- as_tibble(tab) %>%
    mutate(file_id = as.double(row.names(tab))) %>%
    inner_join(manifest)

  return(feat)
}


#' @title Plot of UMAP based on EMD between all files.
#' @export
plot_umap_emd <- function(df, color_col="Sample") {
    df <- df %>%
    mutate(Sample = case_when(control & qc_pass ~ "Control_QC_Pass",
                              control & !qc_pass ~ "Control_QC_Fail",
                              !control & qc_pass ~ "Study_QC_Pass",
                              !control & !qc_pass ~ "Study_QC_Fail",
                              TRUE ~ "Unknown"))

  val_col <- c("Study_QC_Pass"="#619CFF", "Study_QC_Fail"="#F8766D",
               "Control_QC_Pass"="black", "Control_QC_Fail"="purple")

  p <- ggplot(df, aes(x=UMAP1, y=UMAP2, color=.data[[color_col]])) +
    geom_point() +
    theme_bw(base_size=16)

  if (color_col=="Sample")
    return(p + scale_color_manual(values=val_col))
  return(p)
}



